var muestreo={
    "type": "FeatureCollection",
    "features": [
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    0,
                    0
                ]
            },
            "properties": {
                "id": "12",
                "punto": "",
                "titulo": "wew",
                "descripcion": "",
                "institucion": "",
                "ecorregion": "",
                "fuente": "",
                "altura": " msnm",
                "url": "http://"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    0,
                    0
                ]
            },
            "properties": {
                "id": "",
                "punto": "",
                "titulo": "",
                "descripcion": "",
                "institucion": "",
                "ecorregion": "",
                "fuente": "",
                "altura": " msnm",
                "url": "http://"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    43342,
                    34243
                ]
            },
            "properties": {
                "id": "2",
                "punto": "sasa",
                "titulo": "SASSA",
                "descripcion": "asasa",
                "institucion": "dasdsasd",
                "ecorregion": "dsdasad",
                "fuente": "sdsad",
                "altura": "1213 msnm",
                "url": "http://google.com"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    43342,
                    34534
                ]
            },
            "properties": {
                "id": "232",
                "punto": "Demo",
                "titulo": "HOLA MUNDO",
                "descripcion": "LIPSUN",
                "institucion": "UNSALAME",
                "ecorregion": "ABUDABI",
                "fuente": "MI CASA",
                "altura": "12345 msnm",
                "url": "http://google.com"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    43342,
                    34534
                ]
            },
            "properties": {
                "id": "232",
                "punto": "Demo",
                "titulo": "HOLA MUNDO",
                "descripcion": "LIPSUN",
                "institucion": "UNSALAME",
                "ecorregion": "ABUDABI",
                "fuente": "MI CASA",
                "altura": "12345 msnm",
                "url": "http://google.com"
            }
        }
    ]
};